# Signs App Prototype

This is a clickable browser-based prototype for **Signs — Dating Written in the Stars**.

## How to open it
1. Unzip the folder if needed.
2. Double-click `index.html`.
3. It will open in your web browser.

## What works
- Profile entry
- Automatic Sun-sign calculation
- Sign reveal
- Match discovery
- Compatibility page
- Like/pass interaction
- Mutual match screen
- Demo chat

## Important
This is a front-end prototype only. It does not yet include:
- Real accounts
- A database
- Real messaging
- Photo uploads
- Payments
- Live location
- Moderation tools
- App Store packaging

Those features would be added in a production build.
